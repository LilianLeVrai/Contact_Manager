var searchData=
[
  ['removecontactbyid_0',['removeContactById',['../class_list_contact.html#a2cdd7f60749e665c4bc766da72510f9e',1,'ListContact']]],
  ['removeinteractionbyid_1',['removeInteractionById',['../class_list_interaction.html#a1791ae66297cc3619d7a5ffbc7437141',1,'ListInteraction']]],
  ['removetodobyid_2',['removeTodoById',['../class_list_todo.html#acff6b354b90b47d7f73f94b7d98d2460',1,'ListTodo']]]
];
