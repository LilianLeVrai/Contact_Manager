var searchData=
[
  ['addcontact_0',['addContact',['../class_list_contact.html#a67da37c5869b654f39a514a1c159ffc8',1,'ListContact']]],
  ['addinteraction_1',['addInteraction',['../class_list_interaction.html#a2c15ca075a2732f81f186976db6a9b4c',1,'ListInteraction']]],
  ['addtodo_2',['addTodo',['../class_list_todo.html#a0de28e1673eed9992859782e87d54da0',1,'ListTodo']]]
];
