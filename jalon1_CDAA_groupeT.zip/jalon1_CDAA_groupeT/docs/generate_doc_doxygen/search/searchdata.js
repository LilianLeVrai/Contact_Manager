var indexSectionsWithContent =
{
  0: "acdgilrst",
  1: "cdilt",
  2: "cdilt",
  3: "acdgirst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions"
};

